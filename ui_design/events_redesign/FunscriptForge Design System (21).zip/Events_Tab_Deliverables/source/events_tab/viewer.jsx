// Events tab — Right-side MediaViewer (mock).
// Matches the existing FunscriptForge MediaViewer chassis:
// Video/Audio/Spectro/Funscript toggle, big media area, time readout,
// transport controls. Drives the master clock for this tab.

const { useState: mvState } = React;

function EvMediaViewer({ currentMs, isPlaying, onPlayPause, onSeek, onFrameStep, mode, onModeChange, recipeAtPlayhead }) {

  return (
    <div className="ev-mv">
      {/* Mode toggle */}
      <div className="ev-mv__modes">
        {["video", "audio", "spectro", "funscript"].map(m => (
          <button
            key={m}
            className={"ev-mv__mode" + (mode === m ? " ev-mv__mode--on" : "")}
            onClick={() => onModeChange(m)}>{m[0].toUpperCase() + m.slice(1)}</button>
        ))}
      </div>

      {/* Media area */}
      <div className="ev-mv__stage">
        {mode === "video" && <VideoFrame currentMs={currentMs} />}
        {mode === "audio" && <AudioPanel currentMs={currentMs} />}
        {mode === "spectro" && <SpectroPanel currentMs={currentMs} />}
        {mode === "funscript" && <FunscriptPanel currentMs={currentMs} />}

        {/* Live recipe-at-playhead overlay (tiny) */}
        {recipeAtPlayhead && (
          <div className="ev-mv__nowplaying">
            <span className="ev-mv__npdot"
                  style={{ background: recipeAtPlayhead.isBaseline ? "transparent"
                                       : window.EV_familyById(recipeAtPlayhead.family)?.accent,
                           border: recipeAtPlayhead.isBaseline ? "1px dashed #6b7390" : "none" }} />
            <span className="ev-mv__nplbl">{recipeAtPlayhead.label}</span>
          </div>
        )}
      </div>

      {/* Time readout */}
      <div className="ev-mv__time">
        <span className="ev-mv__timeval">{window.EV_fmtTime(currentMs, true)}</span>
        <span className="ev-mv__timedur">/ {window.EV_fmtTime(window.EV_PROJECT.duration_ms)}</span>
      </div>

      {/* Transport */}
      <div className="ev-mv__transport">
        <button className="ev-mv__tbtn" title="Prev chapter">⏮</button>
        <button className="ev-mv__tbtn" title="Frame back" onClick={() => onFrameStep(-1)}>◁I</button>
        <button className="ev-mv__tbtn" title="Step back 1s" onClick={() => onSeek(currentMs - 1000)}>«</button>
        <button className={"ev-mv__tbtn ev-mv__tbtn--play" + (isPlaying ? " ev-mv__tbtn--playing" : "")}
                onClick={onPlayPause} title={isPlaying ? "Pause" : "Play"}>
          {isPlaying ? "▌▌" : "▶"}
        </button>
        <button className="ev-mv__tbtn" title="Step forward 1s" onClick={() => onSeek(currentMs + 1000)}>»</button>
        <button className="ev-mv__tbtn" title="Frame forward" onClick={() => onFrameStep(1)}>I▷</button>
        <button className="ev-mv__tbtn" title="Next chapter">⏭</button>
      </div>

      {/* Slow-mo speed selector */}
      <div className="ev-mv__speed">
        <span className="ev-mv__speedlbl">Speed</span>
        {[0.25, 0.5, 1.0, 2.0].map(s => (
          <button key={s}
            className={"ev-mv__speedbtn" + (s === 1.0 ? " ev-mv__speedbtn--on" : "")}>
            {s}×
          </button>
        ))}
      </div>

      <div className="ev-mv__hint">
        Slow-mo helps land precise begin / end frames without scrubbing.
      </div>
    </div>
  );
}

// ─── Video frame placeholder ───────────────────────────────────────
function VideoFrame({ currentMs }) {
  // Render a "scene" that shifts subtly with currentMs — a stand-in for a real frame.
  const t = (currentMs % 60000) / 60000;
  const palettes = [
    ["#2a1f1a", "#7a4a32", "#c9784a"], // warm
    ["#1f2031", "#5b3954", "#a563a8"], // purple
    ["#1b2c2e", "#3c6a72", "#6abec9"], // teal
    ["#1a2235", "#3b4a6e", "#8095c2"], // blue
  ];
  const palIdx = Math.floor(((currentMs / 1000) / 8) % palettes.length);
  const pal = palettes[palIdx];
  return (
    <div className="ev-mv__video">
      <svg width="100%" height="100%" viewBox="0 0 400 280" preserveAspectRatio="xMidYMid slice">
        <defs>
          <radialGradient id="vfgrad" cx="50%" cy="55%" r="65%">
            <stop offset="0%"  stopColor={pal[2]} stopOpacity="0.7" />
            <stop offset="50%" stopColor={pal[1]} stopOpacity="0.8" />
            <stop offset="100%" stopColor={pal[0]} stopOpacity="1" />
          </radialGradient>
        </defs>
        <rect width="400" height="280" fill="url(#vfgrad)" />
        {/* fake silhouette */}
        <ellipse cx={200 + Math.sin(t * Math.PI * 2) * 25} cy={130} rx="55" ry="48"
                 fill={pal[1]} opacity="0.6" />
        <ellipse cx={200 + Math.sin(t * Math.PI * 2) * 25} cy={200} rx="85" ry="70"
                 fill={pal[1]} opacity="0.6" />
        <text x="20" y="30" fill="#fafafa" opacity="0.45" fontSize="11"
              style={{ fontFamily: "var(--font-mono)" }}>
          [video frame @ {window.EV_fmtTime(currentMs, true)}]
        </text>
        <text x="20" y="265" fill="#fafafa" opacity="0.3" fontSize="10">
          (placeholder · real video would render here)
        </text>
      </svg>
    </div>
  );
}

function AudioPanel({ currentMs }) {
  return (
    <div className="ev-mv__audio">
      <svg width="100%" height="100%" viewBox="0 0 400 280" preserveAspectRatio="none">
        {(() => {
          const N = 200;
          let s = Math.floor(currentMs / 1000) + 1;
          const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
          const center = 140;
          const points = [];
          for (let i = 0; i < N; i++) {
            const env = 0.4 + 0.6 * Math.abs(Math.sin((i / N) * Math.PI * 3));
            const amp = (rand() - 0.5) * env * 110;
            points.push([i * 2, center + amp]);
          }
          return points.map((p, i) => i > 0 && (
            <line key={i} x1={points[i-1][0]} y1={points[i-1][1]} x2={p[0]} y2={p[1]}
                  stroke="#ff8c42" strokeWidth="1" opacity="0.7" />
          ));
        })()}
        <line x1="200" x2="200" y1="0" y2="280" stroke="#ff4b4b" strokeWidth="2" />
      </svg>
    </div>
  );
}

function SpectroPanel({ currentMs }) {
  return (
    <div className="ev-mv__audio">
      <svg width="100%" height="100%" viewBox="0 0 400 280" preserveAspectRatio="none">
        {(() => {
          const cols = 80, rows = 28;
          const cellW = 400 / cols, cellH = 280 / rows;
          let s = Math.floor(currentMs / 500) + 1;
          const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
          const out = [];
          for (let c = 0; c < cols; c++) for (let r = 0; r < rows; r++) {
            const intensity = Math.min(1, (1 - r/rows) * 0.6 + rand() * 0.5);
            const colors = ["#0a1430","#1b3a6b","#2563eb","#06b6d4","#eab308","#f97316","#ef4444"];
            const cIdx = Math.min(colors.length-1, Math.floor(intensity * colors.length));
            out.push(<rect key={`${c}-${r}`} x={c*cellW} y={r*cellH} width={cellW} height={cellH}
                          fill={colors[cIdx]} opacity={intensity * 0.7} />);
          }
          return out;
        })()}
        <line x1="200" x2="200" y1="0" y2="280" stroke="#fafafa" strokeWidth="1.5" opacity="0.8" />
      </svg>
    </div>
  );
}

function FunscriptPanel({ currentMs }) {
  return (
    <div className="ev-mv__audio">
      <svg width="100%" height="100%" viewBox="0 0 400 280" preserveAspectRatio="none">
        {(() => {
          const N = 100;
          let s = Math.floor(currentMs / 1000) + 5;
          const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
          const pts = [];
          for (let i = 0; i < N; i++) {
            const env = 0.5 + 0.5 * Math.sin((i / N) * Math.PI * 4);
            const y = 140 + (env + (rand() - 0.5) * 0.3) * 120 * (i % 2 === 0 ? 1 : -1);
            pts.push([i * 4, y]);
          }
          const colors = ["#1f3a8a","#2563eb","#06b6d4","#22c55e","#eab308","#f97316","#ef4444"];
          return pts.map((p, i) => {
            const cIdx = Math.min(colors.length-1, Math.floor((Math.abs(p[1] - 140) / 140) * colors.length));
            return <circle key={i} cx={p[0]} cy={p[1]} r="2.5" fill={colors[cIdx]} />;
          });
        })()}
        <line x1="200" x2="200" y1="0" y2="280" stroke="#ff4b4b" strokeWidth="2" />
      </svg>
    </div>
  );
}

Object.assign(window, { EvMediaViewer });
