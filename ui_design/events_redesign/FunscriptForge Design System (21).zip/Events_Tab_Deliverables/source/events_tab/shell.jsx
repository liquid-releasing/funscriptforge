// Events tab — Shell: top tab strip + chapter scope row.
// Matches existing FunscriptForge chassis (see Phrases tab screenshot in
// project root). All cosmetic — no real navigation in this prototype.

const { useState: shState, useMemo: shMemo } = React;

const FF_TABS = [
  { id: "library",    label: "Library"    },
  { id: "project",    label: "Project"    },
  { id: "device",     label: "Device"     },
  { id: "chapters",   label: "Chapters"   },
  { id: "motifs",     label: "Motifs",    note: "(was Patterns)" },
  { id: "phrases",    label: "Phrases"    },
  { id: "stanzas",    label: "Stanzas"    },
  { id: "events",     label: "Events",    active: true },
  { id: "characters", label: "Characters" },
  { id: "export",     label: "Export"     },
  { id: "catalog",    label: "Catalog"    },
];

function EvTabStrip() {
  return (
    <div className="ev-tabstrip">
      <div className="ev-tabstrip__brand">
        <span className="ev-tabstrip__anvil" aria-hidden="true">
          {/* simple anvil silhouette */}
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fafafa" strokeWidth="1.6">
            <path d="M3 9h14a3 3 0 0 1 3 3v0H4z" />
            <path d="M7 15h8M9 18h4" />
            <path d="M10 12v3M14 12v3" />
          </svg>
        </span>
        <span className="ev-tabstrip__title">FunscriptForge</span>
        <span className="ev-tabstrip__sep">/</span>
        <span className="ev-tabstrip__file">kiss-the-sky-vH.funscript</span>
      </div>

      <div className="ev-tabstrip__tabs">
        {FF_TABS.map((t, i) => (
          <div key={t.id}
            className={"ev-tab" + (t.active ? " ev-tab--active" : "")}
            title={t.note || t.label}>
            {t.label}
            {t.note && <span className="ev-tab__note">{t.note}</span>}
            {i === 4 && <span className="ev-tabstrip__divider" />}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Chapter scope row ─────────────────────────────────────────────
// Each chapter is a chip showing a small visualization of its event density.
// Click selects that chapter as scope. Width is proportional to chapter
// length so the row reads as a coarse timeline.

function EvChapterRow({ chapters, selectedId, events, onSelect }) {
  const totalMs = chapters[chapters.length - 1].end;

  // Density per chapter — count of events in that chapter.
  const densityByChapter = shMemo(() => {
    const map = {};
    chapters.forEach(c => map[c.id] = events.filter(e => e.begin_ms >= c.start && e.begin_ms < c.end).length);
    return map;
  }, [chapters, events]);

  // Max density for normalization.
  const maxDensity = Math.max(1, ...Object.values(densityByChapter));

  return (
    <div className="ev-chrow">
      <div className="ev-chrow__label">CHAPTERS</div>
      <div className="ev-chrow__chips">
        {chapters.map(ch => {
          const widthPct = ((ch.end - ch.start) / totalMs) * 100;
          const density = densityByChapter[ch.id] || 0;
          const isSelected = ch.id === selectedId;
          const chEvents = events.filter(e => e.begin_ms >= ch.start && e.begin_ms < ch.end);

          return (
            <button
              key={ch.id}
              className={"ev-chchip" + (isSelected ? " ev-chchip--selected" : "")}
              style={{ flexBasis: `${widthPct}%`, flexGrow: widthPct }}
              onClick={() => onSelect(ch.id)}
              title={`${ch.label} · ${density} events`}
            >
              <div className="ev-chchip__label">{ch.id}</div>
              <div className="ev-chchip__name">{ch.label}</div>
              {/* mini event-density viz: dots colored by recipe family */}
              <div className="ev-chchip__viz">
                {chEvents.map(e => {
                  const recipe = window.EV_recipeById(e.recipe);
                  const family = window.EV_familyById(recipe?.family);
                  const leftPct = ((e.begin_ms - ch.start) / (ch.end - ch.start)) * 100;
                  const widthPct = ((e.end_ms - e.begin_ms) / (ch.end - ch.start)) * 100;
                  return (
                    <div
                      key={e.id}
                      className={"ev-chchip__band" + (recipe?.isBaseline ? " ev-chchip__band--baseline" : "")}
                      style={{
                        left: `${leftPct}%`,
                        width: `max(2px, ${widthPct}%)`,
                        background: recipe?.isBaseline ? "transparent" : (family?.accent || "var(--text-muted)"),
                      }}
                    />
                  );
                })}
              </div>
              <div className="ev-chchip__count">
                {density === 0 ? <span className="ev-chchip__count--empty">—</span> : density}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { EvTabStrip, EvChapterRow });
