// Events tab — Capture row (below the editing strip).
// Houses the [Set begin] [Set end] flow, recipe picker, intensity slider,
// per-device chevron, and Add/Update controls. Also renders the
// "selected event" editor when an existing event is selected.
//
// Layout — stacked horizontal bands inside the card so each row breathes:
//   Row 1  · Anchors (Set begin → Set end · duration) ····· [Reset] [+ Add]
//   Row 2  · Recipe picker · Intensity slider
//   Row 3  · Params (per-recipe tunables — flex-wraps; hidden if none)
//   Row 4  · Devices chevron
//   Row 5  · Recipe hint (description + primitive composition)

const { useState: caState, useEffect: caEffect, useRef: caRef, useMemo: caMemo } = React;

// ─── Editable time readout ─────────────────────────────────────────
// Click to switch into an inline text input. Accepts "MM:SS.mmm",
// "MM:SS", or just seconds "234.567". Enter commits; Escape cancels.
function TimeInput({ value, onChange, label, disabled }) {
  const [editing, setEditing] = caState(false);
  const [draft, setDraft] = caState("");
  const inputRef = caRef(null);

  caEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  const parse = (text) => {
    text = String(text || "").trim();
    let m = /^(\d{1,3}):(\d{2})(?:\.(\d{1,3}))?$/.exec(text);
    if (m) {
      const mins = parseInt(m[1], 10);
      const secs = parseInt(m[2], 10);
      if (secs >= 60) return null;
      const mss = m[3] ? parseInt(m[3].padEnd(3, "0").slice(0, 3), 10) : 0;
      return mins * 60000 + secs * 1000 + mss;
    }
    m = /^(\d+(?:\.\d+)?)$/.exec(text);
    if (m) return Math.round(parseFloat(m[1]) * 1000);
    return null;
  };

  const commit = () => {
    const parsed = parse(draft);
    if (parsed != null && parsed >= 0) onChange(parsed);
    setEditing(false);
  };

  if (editing) {
    return (
      <input
        ref={inputRef}
        type="text"
        className="ev-cap__btntime ev-cap__timeinput"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onClick={e => e.stopPropagation()}
        onKeyDown={e => {
          e.stopPropagation();
          if (e.key === "Enter") commit();
          else if (e.key === "Escape") { setDraft(""); setEditing(false); }
        }}
        onBlur={commit}
      />
    );
  }

  return (
    <span
      className={"ev-cap__btntime" + (disabled ? "" : " ev-cap__btntime--editable")}
      onClick={(e) => {
        if (disabled) return;
        e.stopPropagation();
        setDraft(window.EV_fmtTime(value, true));
        setEditing(true);
      }}
      title={disabled ? "" : `Click to type ${label || "time"} directly (MM:SS.mmm)`}
    >
      {window.EV_fmtTime(value, true)}
    </span>
  );
}
// Tiny per-recipe modulation-shape preview rendered as inline SVG.
// Same data the eventual modal palette (#3) will render at larger size.
function RecipePreview({ recipe, w = 64, h = 18, color = "#fafafa" }) {
  if (!recipe) return null;
  const data = recipe.preview || [];
  if (data.length === 0) {
    // Empty (Normal) — show a flat dashed line.
    return (
      <svg width={w} height={h} className="ev-preview" aria-hidden="true">
        <line x1={2} x2={w - 2} y1={h / 2} y2={h / 2}
              stroke={color} strokeWidth="1" strokeDasharray="3 2" opacity="0.4" />
      </svg>
    );
  }
  const pad = 2;
  const usableH = h - pad * 2;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * (w - pad * 2) + pad;
    const y = h - pad - v * usableH;
    return [x, y];
  });
  const d = "M " + points.map(p => `${p[0]},${p[1]}`).join(" L ");
  const dArea = `M ${pad},${h - pad} L ` + points.map(p => `${p[0]},${p[1]}`).join(" L ") + ` L ${w - pad},${h - pad} Z`;
  return (
    <svg width={w} height={h} className="ev-preview" aria-hidden="true">
      <path d={dArea} fill={color} fillOpacity="0.16" />
      <path d={d} stroke={color} strokeWidth="1.2" fill="none" />
    </svg>
  );
}

// ─── Recipe picker — sectioned dropdown with search ────────────────
function RecipePicker({ value, onChange }) {
  const [open, setOpen] = caState(false);
  const [query, setQuery] = caState("");
  const inputRef = caRef(null);
  const recipes = window.EV_RECIPES;
  const families = window.EV_FAMILIES;
  const current = recipes.find(r => r.id === value) || recipes[0];
  const currentFamily = window.EV_familyById(current.family);

  // When the menu opens, autofocus the search input + reset query.
  caEffect(() => {
    if (open) {
      setQuery("");
      // wait one frame for the input to mount
      const id = requestAnimationFrame(() => inputRef.current?.focus());
      return () => cancelAnimationFrame(id);
    }
  }, [open]);

  // Group recipes by family, in the EV_FAMILIES iteration order.
  const grouped = caMemo(() => {
    const q = query.trim().toLowerCase();
    const matches = (r) => !q || r.label.toLowerCase().includes(q) || r.desc.toLowerCase().includes(q) || r.id.includes(q);
    const out = [];
    Object.values(families).forEach(fam => {
      const items = recipes.filter(r => r.family === fam.id && matches(r));
      if (items.length > 0) out.push({ family: fam, items });
    });
    return out;
  }, [query, recipes, families]);

  const totalShown = grouped.reduce((n, g) => n + g.items.length, 0);

  return (
    <div className="ev-picker">
      <button className="ev-picker__btn" onClick={() => setOpen(!open)}>
        <span
          className={"ev-picker__swatch" + (current.isBaseline ? " ev-picker__swatch--baseline" : "")}
          style={{ background: current.isBaseline ? "transparent" : currentFamily?.accent }}
        />
        <span className="ev-picker__label">{current.label}</span>
        <RecipePreview recipe={current} w={48} h={14}
          color={current.isBaseline ? "#9ba3c4" : currentFamily?.accent || "#fafafa"} />
        <span className="ev-picker__chev">▾</span>
      </button>
      {open && (
        <>
          <div className="ev-picker__scrim" onClick={() => setOpen(false)} />
          <div className="ev-picker__menu">
            <div className="ev-picker__search">
              <span className="ev-picker__searchicon">⌕</span>
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Escape") { setOpen(false); }
                  if (e.key === "Enter") {
                    const first = grouped[0]?.items[0];
                    if (first) { onChange(first.id); setOpen(false); }
                  }
                }}
                placeholder={`Search ${recipes.length} recipes…`}
                className="ev-picker__searchinput"
              />
              {query && (
                <button className="ev-picker__clearbtn" onClick={() => setQuery("")}>✕</button>
              )}
            </div>

            <div className="ev-picker__results">
              {grouped.length === 0 && (
                <div className="ev-picker__empty">
                  No recipes match "{query}"
                </div>
              )}
              {grouped.map(({ family: fam, items }) => (
                <div key={fam.id} className="ev-picker__group">
                  <div className="ev-picker__grouphead">
                    <span className="ev-picker__groupdot" style={{ background: fam.accent }} />
                    <span className="ev-picker__grouplbl" style={{ color: fam.accent }}>{fam.label}</span>
                    <span className="ev-picker__groupcount">{items.length}</span>
                  </div>
                  {items.map(r => {
                    const isOn = r.id === value;
                    return (
                      <button
                        key={r.id}
                        className={"ev-picker__item" + (isOn ? " ev-picker__item--on" : "")}
                        onClick={() => { onChange(r.id); setOpen(false); }}
                      >
                        <span
                          className={"ev-picker__swatch" + (r.isBaseline ? " ev-picker__swatch--baseline" : "")}
                          style={{ background: r.isBaseline ? "transparent" : fam.accent }}
                        />
                        <span className="ev-picker__itemmain">
                          <span className="ev-picker__itemlabel">{r.label}</span>
                          <span className="ev-picker__itemdesc">{r.desc}</span>
                        </span>
                        <RecipePreview recipe={r} w={64} h={20}
                          color={r.isBaseline ? "#6b7390" : fam.accent} />
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            <div className="ev-picker__footer">
              <span className="ev-picker__foothint">
                {totalShown} of {recipes.length} · {recipes.length < 30 ? "" : "type to filter"}
              </span>
              <button className="ev-picker__paletteopen" disabled title="Coming when the recipe library grows past ~30">
                ↗ Browse palette
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Intensity slider ──────────────────────────────────────────────
function IntensitySlider({ value, onChange, disabled }) {
  return (
    <div className={"ev-intensity" + (disabled ? " ev-intensity--disabled" : "")}>
      <label className="ev-intensity__label">Intensity</label>
      <input
        type="range" min={0} max={1} step={0.01}
        value={value} disabled={disabled}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="ev-intensity__range"
      />
      <span className="ev-intensity__read">{Math.round(value * 100)}</span>
    </div>
  );
}

// ─── Recipe params (per-recipe tunables) ───────────────────────────
function RecipeParams({ recipe, params, onChange, disabled }) {
  if (!recipe?.tunables || recipe.tunables.length === 0) return null;
  return (
    <div className={"ev-params" + (disabled ? " ev-params--disabled" : "")}>
      <span className="ev-params__label">Params</span>
      <div className="ev-params__list">
        {recipe.tunables.map(t => {
          const v = params[t.key] != null ? params[t.key] : t.default;
          const display = t.step < 1
            ? v.toFixed(t.step < 0.1 ? 2 : 1)
            : Math.round(v);
          return (
            <div key={t.key} className="ev-params__item">
              <span className="ev-params__name">{t.label}</span>
              <input
                type="range"
                min={t.min} max={t.max} step={t.step}
                value={v}
                disabled={disabled}
                onChange={e => onChange({ ...params, [t.key]: parseFloat(e.target.value) })}
                className="ev-params__range"
              />
              <span className="ev-params__val">{display}{t.unit && <span className="ev-params__unit">{t.unit}</span>}</span>
            </div>
          );
        })}
        <button
          className="ev-params__reset"
          onClick={() => {
            const defaults = {};
            recipe.tunables.forEach(t => { defaults[t.key] = t.default; });
            onChange(defaults);
          }}
          title="Reset to recipe defaults"
        >↻</button>
      </div>
    </div>
  );
}

// ─── Per-device chevron ────────────────────────────────────────────
function DeviceChevron({ devices, onChange }) {
  const [open, setOpen] = caState(false);
  const all = window.EV_DEVICES;
  const summary = all
    .map(d => devices[d.id] != null ? `${d.id} ${Math.round(devices[d.id] * 100)}` : null)
    .filter(Boolean)
    .join(" · ") || "broadcast (all 100%)";

  return (
    <div className="ev-devchev">
      <button className="ev-devchev__btn" onClick={() => setOpen(!open)}>
        <span className="ev-devchev__lbl">Devices</span>
        <span className="ev-devchev__sum">{summary}</span>
        <span className="ev-devchev__chev">{open ? "▴" : "▾"}</span>
      </button>
      {open && (
        <div className="ev-devchev__panel">
          {all.map(d => {
            const v = devices[d.id];
            const isOverridden = v != null;
            return (
              <div key={d.id} className="ev-devchev__row">
                <button
                  className={"ev-devchev__toggle" + (isOverridden ? " ev-devchev__toggle--on" : "")}
                  onClick={() => onChange({ ...devices, [d.id]: isOverridden ? undefined : 1.0 })}
                  title={isOverridden ? "Remove override (broadcast at 100%)" : "Add override"}
                >
                  {isOverridden ? "●" : "○"}
                </button>
                <span className="ev-devchev__name">{d.label}</span>
                <input
                  type="range" min={0} max={1} step={0.05}
                  value={isOverridden ? v : 1.0}
                  disabled={!isOverridden}
                  onChange={e => onChange({ ...devices, [d.id]: parseFloat(e.target.value) })}
                  className="ev-devchev__range"
                />
                <span className="ev-devchev__read">
                  {isOverridden ? Math.round(v * 100) : <span className="ev-devchev__read--dim">100</span>}
                </span>
              </div>
            );
          })}
          <div className="ev-devchev__hint">
            ○ = broadcast at full intensity · ● = per-device override
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Capture row ───────────────────────────────────────────────────
function CaptureRow({
  beginMs, endMs, currentMs,
  onBeginMsChange, onEndMsChange,
  recipeId, onRecipeChange,
  intensity, onIntensityChange,
  params, onParamsChange,
  devices, onDevicesChange,
  chainMode, onChainModeChange,
  beatSnap, onBeatSnapChange,
  onSetBegin, onSetEnd, onClear, onAdd,
  selectedEvent, onUpdateSelected, onDeleteSelected, onDeselect,
}) {
  if (selectedEvent) {
    return <SelectedEventEditor
      ev={selectedEvent}
      onUpdate={onUpdateSelected}
      onDelete={onDeleteSelected}
      onDeselect={onDeselect}
    />;
  }

  const currentRecipe = window.EV_recipeById(recipeId);
  const isBaseline = !!currentRecipe?.isBaseline;
  const canAdd = beginMs != null && endMs != null && endMs > beginMs;
  const isTap = !!currentRecipe?.tapToCreate;
  const canTapAdd = isTap && beginMs != null && endMs == null;
  const effectiveCanAdd = canAdd || canTapAdd;
  const autoEndPreview = (canTapAdd && currentRecipe?.defaults?.duration_ms)
    ? beginMs + currentRecipe.defaults.duration_ms : null;
  const duration = canAdd ? endMs - beginMs : (canTapAdd ? currentRecipe.defaults.duration_ms : 0);

  return (
    <div className="ev-cap">
      <div className="ev-cap__head">
        <span className="ev-cap__title">Capture event</span>
        <div className="ev-cap__chain">
          <label className="ev-cap__chip">
            <input type="checkbox" checked={chainMode} onChange={e => onChainModeChange(e.target.checked)} />
            <span>Chain — next begin = previous end</span>
          </label>
          <label className="ev-cap__chip">
            <input type="checkbox" checked={beatSnap} onChange={e => onBeatSnapChange(e.target.checked)} />
            <span>Snap to beat</span>
          </label>
        </div>
      </div>

      {/* Row 1 — Anchors + actions */}
      <div className="ev-cap__band ev-cap__band--anchors">
        <button
          className={"ev-cap__btn" + (beginMs != null ? " ev-cap__btn--set" : "")}
          onClick={onSetBegin}>
          <span className="ev-cap__btnlbl">{beginMs != null ? "Begin set" : "Set begin"}</span>
          {beginMs != null
            ? <TimeInput value={beginMs} onChange={onBeginMsChange} label="begin" />
            : <span className="ev-cap__btntime">at playhead →</span>}
        </button>
        <div className="ev-cap__sep">→</div>
        <button
          className={"ev-cap__btn" + (endMs != null ? " ev-cap__btn--set" : "") + (beginMs == null ? " ev-cap__btn--dim" : "") + (canTapAdd ? " ev-cap__btn--auto" : "")}
          onClick={onSetEnd}
          disabled={beginMs == null}>
          <span className="ev-cap__btnlbl">{endMs != null ? "End set" : (canTapAdd ? "End (auto)" : "Set end")}</span>
          {endMs != null
            ? <TimeInput value={endMs} onChange={onEndMsChange} label="end" />
            : canTapAdd
              ? <span className="ev-cap__btntime">+ {currentRecipe.defaults.duration_ms} ms</span>
              : <span className="ev-cap__btntime">at playhead →</span>}
        </button>
        <div className="ev-cap__dur">
          <span className="ev-cap__durlbl">Duration</span>
          <span className="ev-cap__durval">{duration > 0 ? window.EV_fmtTime(duration, true) : "––:––.–––"}</span>
        </div>
        <div className="ev-cap__spacer" />
        <button className="ev-cap__clear" onClick={onClear} disabled={beginMs == null && endMs == null}>↻ Reset</button>
        <button
          className={"ev-cap__add" + (effectiveCanAdd ? " ev-cap__add--ready" : "") + (canTapAdd ? " ev-cap__add--tap" : "")}
          onClick={onAdd}
          disabled={!effectiveCanAdd}>
          {canTapAdd ? "+ Add hit" : "+ Add event"}
        </button>
      </div>

      {/* Row 2 — Recipe + Intensity */}
      <div className="ev-cap__band ev-cap__band--recipe">
        <span className="ev-cap__bandlbl">Recipe</span>
        <RecipePicker value={recipeId} onChange={onRecipeChange} />
        <IntensitySlider
          value={intensity}
          onChange={onIntensityChange}
          disabled={isBaseline}
        />
      </div>

      {/* Row 3 — Recipe params (only when recipe has tunables) */}
      <RecipeParams
        recipe={currentRecipe}
        params={params}
        onChange={onParamsChange}
        disabled={isBaseline}
      />

      {/* Row 4 — Devices chevron */}
      <div className="ev-cap__band ev-cap__band--devices">
        <DeviceChevron devices={devices} onChange={onDevicesChange} />
      </div>

      {/* Row 5 — Hint */}
      {currentRecipe && (
        <div className="ev-cap__hint">
          <span className="ev-cap__hintlbl">{currentRecipe.label}:</span>
          <span className="ev-cap__hintdesc">{currentRecipe.desc}</span>
          <span className={"ev-cap__hintcompose ev-cap__hintcompose--" + (currentRecipe.compose || "additive")}>
            {currentRecipe.compose === "replace" ? "↺ replaces underlying" : "+ additive"}
          </span>
          {currentRecipe.primitives.length > 0 && (
            <span className="ev-cap__hintprim">
              ⟶ {currentRecipe.primitives.map(p => p.pattern).join(" + ")}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Selected event editor ─────────────────────────────────────────
function SelectedEventEditor({ ev, onUpdate, onDelete, onDeselect }) {
  const recipe = window.EV_recipeById(ev.recipe);
  const family = window.EV_familyById(recipe?.family);
  const duration = ev.end_ms - ev.begin_ms;
  const isBaseline = !!recipe?.isBaseline;

  return (
    <div className="ev-cap ev-cap--editing">
      <div className="ev-cap__head">
        <span className="ev-cap__title">
          <span
            className={"ev-picker__swatch" + (isBaseline ? " ev-picker__swatch--baseline" : "")}
            style={{ background: isBaseline ? "transparent" : family?.accent, marginRight: 8, verticalAlign: "middle" }}
          />
          Editing event · <code className="ev-cap__id">{ev.id}</code>
        </span>
        <button className="ev-cap__close" onClick={onDeselect}>✕ Done</button>
      </div>

      {/* Row 1 — Begin/End readouts + nudges + delete */}
      <div className="ev-cap__band ev-cap__band--anchors">
        <div className="ev-cap__btn ev-cap__btn--set ev-cap__btn--readout">
          <span className="ev-cap__btnlbl">Begin</span>
          <TimeInput value={ev.begin_ms} onChange={(v) => onUpdate({ begin_ms: Math.min(ev.end_ms - 200, v) })} label="begin" />
        </div>
        <div className="ev-cap__sep">→</div>
        <div className="ev-cap__btn ev-cap__btn--set ev-cap__btn--readout">
          <span className="ev-cap__btnlbl">End</span>
          <TimeInput value={ev.end_ms} onChange={(v) => onUpdate({ end_ms: Math.max(ev.begin_ms + 200, v) })} label="end" />
        </div>
        <div className="ev-cap__dur">
          <span className="ev-cap__durlbl">Duration</span>
          <span className="ev-cap__durval">{window.EV_fmtTime(duration, true)}</span>
        </div>
        <div className="ev-cap__nudge">
          <button className="ev-cap__nudgebtn" title="Move begin to playhead"
                  onClick={() => onUpdate({ begin_ms: window.__evPlayhead })}>← begin to ▸</button>
          <button className="ev-cap__nudgebtn" title="Move end to playhead"
                  onClick={() => onUpdate({ end_ms: window.__evPlayhead })}>▸ to end →</button>
        </div>
        <div className="ev-cap__spacer" />
        <button className="ev-cap__delete" onClick={onDelete}>🗑 Delete</button>
      </div>

      {/* Row 2 — Recipe + Intensity */}
      <div className="ev-cap__band ev-cap__band--recipe">
        <span className="ev-cap__bandlbl">Recipe</span>
        <RecipePicker value={ev.recipe} onChange={(id) => onUpdate({ recipe: id })} />
        <IntensitySlider
          value={ev.intensity}
          onChange={(v) => onUpdate({ intensity: v })}
          disabled={isBaseline}
        />
      </div>

      {/* Row 3 — Recipe params */}
      <RecipeParams
        recipe={recipe}
        params={ev.params || {}}
        onChange={(p) => onUpdate({ params: p })}
        disabled={isBaseline}
      />

      {/* Row 4 — Devices */}
      <div className="ev-cap__band ev-cap__band--devices">
        <DeviceChevron
          devices={ev.devices || {}}
          onChange={(d) => onUpdate({ devices: d })}
        />
      </div>
    </div>
  );
}

Object.assign(window, { CaptureRow });
