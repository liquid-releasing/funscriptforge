// Events tab — mock data for the high-fi design prototype.
// Recipe catalog mirrors what would eventually live in forgeworkbench's
// recipe library. Each recipe is a NAMED COMPOSITION of pattern primitives
// (Pulse, Wave, Tremor, Sustain, Rolling, Impact) — recipes are what users
// pick in Events; primitives are what the engine renders.

window.EV_FAMILIES = {
  baseline:  { id: "baseline",  label: "Baseline",   accent: "#6b7390" },  // normal / pass-through
  edging:    { id: "edging",    label: "Edging",     accent: "#ff7b7b" },  // tension/build/edge
  release:   { id: "release",   label: "Release",    accent: "#ff8c42" },  // crescendo/climax
  rhythm:    { id: "rhythm",    label: "Rhythm",     accent: "#4dabf7" },  // pulse/wave loops
  punctuate: { id: "punctuate", label: "Punctuate",  accent: "#c77dff" },  // impact/sharp
  texture:   { id: "texture",   label: "Texture",    accent: "#3ed598" },  // ambient layer
};

// Recipes — what the user picks in the Events tab.
// `primitives` is the underlying composition that gets exported.
// `compose` controls how the event interacts with whatever else is playing:
//   - "additive" (default): layers on top, capped at 1.0 per device.
//   - "replace":  overrides everything underneath for the span. Normal
//                 uses this — that's how it acts as the eraser.
// Normal is the eraser — explicitly clears a span back to baseline. Picker
// default; renders as hatched gray on the strip (negative space, not a
// competing color band).
window.EV_RECIPES = [
  { id: "normal", label: "Normal", family: "baseline",
    desc: "Pass-through. No emphasis. Use to clear a span back to baseline when the surrounding phrase or chapter would otherwise apply a recipe.",
    primitives: [],
    defaults: { intensity: 0, duration_ms: 2000 },
    tunables: [],
    isBaseline: true,
    compose: "replace",
    preview: [0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10],
  },
  { id: "surge",  label: "Surge",  family: "release",
    desc: "Slow ramp-in, sustained throb, slow ramp-out. Big release moments.",
    primitives: [
      { pattern: "wave",    period: "0.5b", envelope: "ramp-in"  },
      { pattern: "sustain", level: 0.85,    envelope: "hold"     },
      { pattern: "wave",    period: "1b",   envelope: "ramp-out" },
    ],
    defaults: { intensity: 0.85, duration_ms: 8000 },
    tunables: [
      { key: "ramp_in_ms",  label: "Ramp in",  min: 200,  max: 4000, step: 100, default: 800,  unit: "ms" },
      { key: "throb_freq",  label: "Throb",    min: 0.5,  max: 4,    step: 0.1, default: 1.5,  unit: "Hz" },
      { key: "ramp_out_ms", label: "Ramp out", min: 500,  max: 8000, step: 100, default: 2500, unit: "ms" },
    ],
    preview: [0.10,0.18,0.30,0.42,0.55,0.68,0.78,0.85,0.82,0.85,0.78,0.82,0.85,0.80,0.78,0.72,0.65,0.55,0.46,0.38,0.30,0.22,0.16,0.12],
  },
  { id: "edge",   label: "Edge",   family: "edging",
    desc: "Tension build — quick pulse ramp with 10Hz volume buzz.",
    primitives: [
      { pattern: "pulse",  period: "0.25b", envelope: "ramp-in" },
      { pattern: "tremor", freq:   "10hz",  amount:   0.30      },
    ],
    defaults: { intensity: 0.70, duration_ms: 3500 },
    tunables: [
      { key: "tremor_freq",   label: "Tremor",     min: 1,   max: 20,  step: 0.5,  default: 10,   unit: "Hz" },
      { key: "tremor_amount", label: "Tremor amt", min: 0,   max: 1,   step: 0.05, default: 0.30, unit: ""   },
      { key: "ramp_up_ms",    label: "Ramp up",    min: 50,  max: 1500,step: 50,   default: 250,  unit: "ms" },
    ],
    preview: [0.15,0.28,0.42,0.55,0.70,0.62,0.78,0.65,0.82,0.68,0.85,0.72,0.88,0.74,0.85,0.71,0.82,0.68,0.78,0.62,0.72,0.55,0.65,0.48],
  },
  { id: "tease",  label: "Tease",  family: "edging",
    desc: "Light flutter with held breath. Anticipation.",
    primitives: [
      { pattern: "tremor", freq: "6hz", amount: 0.15 },
      { pattern: "wave",   period: "2b", level: 0.35 },
    ],
    defaults: { intensity: 0.45, duration_ms: 5000 },
    tunables: [
      { key: "flutter_freq",   label: "Flutter",    min: 1, max: 15,  step: 0.5,  default: 6,    unit: "Hz" },
      { key: "flutter_amount", label: "Flutter amt",min: 0, max: 1,   step: 0.05, default: 0.15, unit: ""   },
    ],
    preview: [0.25,0.35,0.30,0.40,0.32,0.42,0.34,0.44,0.36,0.46,0.34,0.44,0.32,0.42,0.34,0.44,0.36,0.46,0.38,0.48,0.36,0.46,0.34,0.42],
  },
  { id: "climax", label: "Climax", family: "release",
    desc: "Hard crescendo, peak intensity. Saved for the moment.",
    primitives: [
      { pattern: "pulse",   period: "0.125b", envelope: "ramp-in" },
      { pattern: "impact",  amount: 1.0 },
      { pattern: "sustain", level: 1.0, envelope: "decay" },
    ],
    defaults: { intensity: 1.00, duration_ms: 6000 },
    tunables: [
      { key: "ramp_up_ms", label: "Ramp up", min: 200, max: 4000, step: 100, default: 1200, unit: "ms" },
      { key: "decay_ms",   label: "Decay",   min: 500, max: 6000, step: 100, default: 2500, unit: "ms" },
    ],
    preview: [0.12,0.18,0.28,0.42,0.60,0.78,0.92,1.00,1.00,0.98,1.00,0.95,1.00,0.92,0.88,0.82,0.75,0.65,0.55,0.42,0.30,0.20,0.14,0.10],
  },
  { id: "impact", label: "Impact", family: "punctuate",
    desc: "Single hit. Gunshot, slap, punch landing.",
    primitives: [
      { pattern: "impact", amount: 1.0, envelope: "snap" },
    ],
    defaults: { intensity: 0.90, duration_ms: 350 },
    tapToCreate: true,   // short-shape recipe — Set End auto-derives from default duration
    tunables: [
      { key: "attack_ms", label: "Attack", min: 5,  max: 200, step: 5,  default: 20,  unit: "ms" },
      { key: "decay_ms",  label: "Decay",  min: 50, max: 800, step: 25, default: 250, unit: "ms" },
    ],
    preview: [0.05,0.05,0.10,1.00,0.85,0.65,0.48,0.35,0.25,0.18,0.12,0.08,0.06,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05],
  },
  { id: "pulse",  label: "Pulse",  family: "rhythm",
    desc: "Steady on-beat pulse. The metronome.",
    primitives: [
      { pattern: "pulse", period: "1b" },
    ],
    defaults: { intensity: 0.60, duration_ms: 4000 },
    tunables: [
      { key: "period_beats", label: "Period", min: 0.25, max: 4, step: 0.25, default: 1, unit: "b" },
    ],
    preview: [0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65,0.20,0.65],
  },
  { id: "rolling", label: "Rolling", family: "rhythm",
    desc: "Continuous swell, ocean-wave shape.",
    primitives: [
      { pattern: "rolling", period: "2b", amount: 0.7 },
    ],
    defaults: { intensity: 0.65, duration_ms: 6000 },
    tunables: [
      { key: "period_beats", label: "Period", min: 1, max: 8, step: 0.5,  default: 2,   unit: "b" },
      { key: "amount",       label: "Depth",  min: 0, max: 1, step: 0.05, default: 0.7, unit: ""  },
    ],
    preview: [0.50,0.62,0.74,0.82,0.85,0.82,0.74,0.62,0.50,0.38,0.26,0.18,0.15,0.18,0.26,0.38,0.50,0.62,0.74,0.82,0.85,0.78,0.66,0.54],
  },
  { id: "soften", label: "Soften", family: "texture",
    desc: "Drop intensity floor. Recovery / aftercare.",
    primitives: [
      { pattern: "sustain", level: 0.20, envelope: "ease-in" },
    ],
    defaults: { intensity: 0.30, duration_ms: 4000 },
    tunables: [
      { key: "floor_level", label: "Floor", min: 0, max: 0.5, step: 0.02, default: 0.20, unit: "" },
      { key: "ease_ms",     label: "Ease",  min: 200, max: 4000, step: 100, default: 1200, unit: "ms" },
    ],
    preview: [0.65,0.60,0.55,0.48,0.42,0.36,0.30,0.26,0.24,0.22,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20,0.20],
  },
];

// Device targets — for the per-device chevron.
window.EV_DEVICES = [
  { id: "estim",    label: "E-stim",    icon: "zap"     },
  { id: "vibrator", label: "Vibrator",  icon: "radio"   },
  { id: "bhaptics", label: "bHaptics",  icon: "shirt"   },
  { id: "shaker",   label: "Shaker",    icon: "speaker" },
];

// Mock chapters — match existing FunscriptForge chapter shape.
window.EV_CHAPTERS = [
  { id: "ch1", label: "Opening",  start:      0, end:  60000, color: "#5b8fff" },
  { id: "ch2", label: "Build",    start:  60000, end: 180000, color: "#4dabf7" },
  { id: "ch3", label: "Rising",   start: 180000, end: 360000, color: "#ff8c42" },
  { id: "ch4", label: "Heated",   start: 360000, end: 540000, color: "#ff4b4b" },
  { id: "ch5", label: "Climax",   start: 540000, end: 660000, color: "#ff5470" },
  { id: "ch6", label: "Aftercare", start: 660000, end: 720000, color: "#3ed598" },
];

// Sample events — what the strip renders. begin_ms / end_ms in project time.
// Recipe id references EV_RECIPES.
// Note: some pairs are deliberately overlapping to demonstrate lane-packing
// + compose modes (Impact on top of Surge = additive stack; Normal during a
// busy stretch = replace, briefly stops everything).
window.EV_SAMPLE_EVENTS = [
  // Chapter 3 — Rising (180000–360000)
  { id: "e01", begin_ms: 192000, end_ms: 195500, recipe: "tease",  intensity: 0.50, devices: {} },
  { id: "e02", begin_ms: 198400, end_ms: 203100, recipe: "edge",   intensity: 0.65, devices: {} },
  { id: "e03", begin_ms: 205800, end_ms: 207100, recipe: "impact", intensity: 0.85, devices: { estim: 1.0, vibrator: 0.7, shaker: 1.0 } },
  { id: "e04", begin_ms: 212000, end_ms: 218400, recipe: "rolling",intensity: 0.60, devices: {} },
  { id: "e05", begin_ms: 224500, end_ms: 232000, recipe: "edge",   intensity: 0.72, devices: {} },
  // Surge with an Impact landing INSIDE it (stack — additive)
  { id: "e06", begin_ms: 240000, end_ms: 248500, recipe: "surge",  intensity: 0.80, devices: {} },
  { id: "e06b",begin_ms: 244300, end_ms: 244700, recipe: "impact", intensity: 0.95, devices: { shaker: 1.0 } },
  // Three short impacts in a row
  { id: "e07", begin_ms: 254200, end_ms: 256100, recipe: "impact", intensity: 0.90, devices: { shaker: 1.0 } },
  { id: "e08", begin_ms: 258000, end_ms: 259400, recipe: "impact", intensity: 0.90, devices: { shaker: 1.0 } },
  { id: "e09", begin_ms: 261200, end_ms: 262700, recipe: "impact", intensity: 0.90, devices: { shaker: 1.0 } },
  { id: "e10", begin_ms: 265000, end_ms: 271500, recipe: "edge",   intensity: 0.80, devices: {} },
  { id: "e11", begin_ms: 274000, end_ms: 286400, recipe: "tease",  intensity: 0.55, devices: {} },
  // Normal slicing INTO a Tease — "briefly stops everything" (replace)
  { id: "e_q", begin_ms: 280500, end_ms: 282500, recipe: "normal", intensity: 0,    devices: {} },
  // Surge with a Pulse layered on top (stack — additive)
  { id: "e12", begin_ms: 292000, end_ms: 302500, recipe: "surge",  intensity: 0.88, devices: {} },
  { id: "e12b",begin_ms: 295200, end_ms: 300100, recipe: "pulse",  intensity: 0.50, devices: {} },
  { id: "e13", begin_ms: 308000, end_ms: 312800, recipe: "pulse",  intensity: 0.55, devices: {} },
  { id: "e14", begin_ms: 318000, end_ms: 326400, recipe: "edge",   intensity: 0.82, devices: {} },
  { id: "e15", begin_ms: 332000, end_ms: 342500, recipe: "surge",  intensity: 0.92, devices: {} },
  // Normal carving a recovery pocket inside the Surge
  { id: "e_q2",begin_ms: 337000, end_ms: 338800, recipe: "normal", intensity: 0,    devices: {} },
  { id: "e16", begin_ms: 348000, end_ms: 354100, recipe: "tease",  intensity: 0.50, devices: {} },
];

// Project / file mock.
window.EV_PROJECT = {
  title: "kiss-the-sky-vH.funscript",
  duration_ms: 720000, // 12:00
  actions: 2183,
  beat: { bpm: 92, source: "detected" },
};

// Helpers.
window.EV_fmtTime = function (ms, withMs = false) {
  if (ms == null || isNaN(ms)) return "––:––";
  const totalSec = ms / 1000;
  const m = Math.floor(totalSec / 60);
  const s = Math.floor(totalSec % 60);
  const mss = Math.floor(ms % 1000);
  const base = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  if (!withMs) return base;
  return `${base}.${String(mss).padStart(3, "0")}`;
};

window.EV_recipeById = function (id) {
  return window.EV_RECIPES.find(r => r.id === id);
};

window.EV_familyById = function (id) {
  return window.EV_FAMILIES[id];
};
