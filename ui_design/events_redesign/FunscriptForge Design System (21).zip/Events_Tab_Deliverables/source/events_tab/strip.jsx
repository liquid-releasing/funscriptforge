// Events tab — Editing strip.
// The main editing canvas: zoomable timeline scoped to the active chapter,
// toggleable background (Video thumbs / Audio / Spectro / Funscript / None),
// events as labeled colored brackets in lanes, playhead, beat markers,
// ghost-bracket while capturing.

const { useState: stState, useMemo: stMemo, useRef: stRef, useEffect: stEffect } = React;

// Pack overlapping events into lanes — greedy left-to-right.
function packLanes(events) {
  const sorted = [...events].sort((a, b) => a.begin_ms - b.begin_ms);
  const lanes = []; // each lane is { endMs, items: [event] }
  const out = sorted.map(ev => {
    let laneIdx = lanes.findIndex(l => l.endMs <= ev.begin_ms);
    if (laneIdx === -1) {
      lanes.push({ endMs: ev.end_ms });
      laneIdx = lanes.length - 1;
    } else {
      lanes[laneIdx].endMs = ev.end_ms;
    }
    return { ...ev, lane: laneIdx };
  });
  return { events: out, laneCount: Math.max(1, lanes.length) };
}

// ─── Backgrounds ───────────────────────────────────────────────────
function VideoThumbStrip({ width, height, scope }) {
  // Render N "thumbnails" as gradient blocks with a frame border.
  const thumbCount = Math.floor(width / 80);
  const thumbW = width / thumbCount;
  const palettes = [
    ["#1a2235", "#3b4a6e"], ["#1f2031", "#5b3954"], ["#1b2c2e", "#3c6a72"],
    ["#2a1f1a", "#7a4a32"], ["#1f1f2a", "#5a5a8a"], ["#181b22", "#2e3550"],
    ["#221a26", "#5e3a6e"], ["#1f1a18", "#7a3e2a"], ["#1a2630", "#3a6080"],
    ["#221d18", "#6a4a32"], ["#1b1f24", "#3a4a64"], ["#2a1f28", "#7a4a78"],
    ["#1a1d27", "#383e5a"], ["#1d1a22", "#4a3a5e"], ["#221a1d", "#7a3a4a"],
  ];
  return (
    <g>
      {Array.from({ length: thumbCount }).map((_, i) => {
        const x = i * thumbW;
        const pal = palettes[i % palettes.length];
        return (
          <g key={i}>
            <defs>
              <linearGradient id={`thumb-${i}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={pal[1]} stopOpacity="0.35" />
                <stop offset="100%" stopColor={pal[0]} stopOpacity="0.6" />
              </linearGradient>
            </defs>
            <rect x={x + 1} y={2} width={thumbW - 2} height={height - 4}
                  fill={`url(#thumb-${i})`} />
            {/* fake silhouette suggestion */}
            <circle cx={x + thumbW * 0.45} cy={height * 0.55} r={height * 0.18}
                    fill={pal[1]} opacity="0.5" />
            <rect x={x + thumbW * 0.25} y={height * 0.72} width={thumbW * 0.5} height={height * 0.18}
                  fill={pal[1]} opacity="0.4" />
          </g>
        );
      })}
    </g>
  );
}

function AudioWaveBg({ width, height, scope, seed = 7 }) {
  // Deterministic pseudo-random waveform.
  const samples = Math.floor(width / 2);
  let s = seed;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const points = [];
  for (let i = 0; i < samples; i++) {
    const x = (i / samples) * width;
    const env = 0.4 + 0.6 * Math.sin((i / samples) * Math.PI * 2.3 + 1.2);
    const amp = (rand() - 0.5) * 2 * env;
    points.push([x, height / 2 + amp * (height / 2 - 4)]);
  }
  const dTop = "M " + points.map(p => `${p[0]},${p[1]}`).join(" L ");
  const mirror = points.map(p => `${p[0]},${height - p[1]}`).reverse();
  const dPath = dTop + " L " + mirror.join(" L ") + " Z";
  return (
    <path d={dPath} fill="#4dabf7" fillOpacity="0.22" stroke="#4dabf7" strokeOpacity="0.45" strokeWidth="0.5" />
  );
}

function SpectroBg({ width, height }) {
  // Synth: bands of color modulating over time.
  const cols = Math.floor(width / 3);
  const rows = 16;
  const cellW = width / cols;
  const cellH = height / rows;
  const cells = [];
  let s = 13;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const colorAt = (intensity) => {
    if (intensity < 0.15) return ["#0a1430", 0];
    if (intensity < 0.35) return ["#1b3a6b", 0.5];
    if (intensity < 0.55) return ["#2563eb", 0.6];
    if (intensity < 0.75) return ["#06b6d4", 0.65];
    if (intensity < 0.9)  return ["#eab308", 0.7];
    return ["#f97316", 0.85];
  };
  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      // Low rows = bass = often higher amplitude; pulse to columns.
      const colEnergy = 0.3 + 0.7 * Math.abs(Math.sin((c / cols) * Math.PI * 4 + r * 0.3));
      const rowBias = 1 - (r / rows) * 0.7;
      const noise = rand() * 0.5;
      const intensity = Math.min(1, colEnergy * rowBias * 0.9 + noise * 0.3);
      const [color, opacity] = colorAt(intensity);
      if (opacity > 0) cells.push({ x: c * cellW, y: r * cellH, w: cellW, h: cellH, color, opacity });
    }
  }
  return (
    <g>
      {cells.map((cell, i) => (
        <rect key={i} x={cell.x} y={cell.y} width={cell.w} height={cell.h}
              fill={cell.color} opacity={cell.opacity} />
      ))}
    </g>
  );
}

function FunscriptBg({ width, height }) {
  // Synth: undulating curve in the FF velocity gradient.
  const samples = Math.floor(width / 2);
  let s = 31;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const points = [];
  for (let i = 0; i < samples; i++) {
    const x = (i / samples) * width;
    const env = 0.5 + 0.5 * Math.sin((i / samples) * Math.PI * 5);
    const noise = (rand() - 0.5) * 0.3;
    const y = height / 2 + (env + noise) * (height / 2 - 6) * (i % 2 === 0 ? 1 : -1);
    points.push([x, y]);
  }
  return (
    <g>
      {points.map((p, i) => {
        if (i === 0) return null;
        const prev = points[i - 1];
        const v = Math.abs(p[1] - prev[1]) / (height / 2);
        const colors = ["#1f3a8a", "#2563eb", "#06b6d4", "#22c55e", "#eab308", "#f97316", "#ef4444"];
        const cIdx = Math.min(colors.length - 1, Math.floor(v * colors.length));
        return <circle key={i} cx={p[0]} cy={p[1]} r="1.5" fill={colors[cIdx]} opacity="0.7" />;
      })}
    </g>
  );
}

function EnergyBg({ width, height }) {
  // Synth: a smoothed RMS-like energy envelope. Area chart from the baseline.
  const samples = Math.floor(width / 3);
  let s = 53;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  // Build raw signal, then smooth with a moving average.
  const raw = [];
  for (let i = 0; i < samples; i++) {
    const slow  = 0.40 + 0.35 * Math.sin((i / samples) * Math.PI * 2.5 + 0.4);
    const fast  = 0.20 * Math.sin((i / samples) * Math.PI * 13);
    const noise = (rand() - 0.5) * 0.12;
    raw.push(Math.max(0, slow + fast + noise));
  }
  const smoothed = raw.map((_, i) => {
    const w = 4;
    let sum = 0, n = 0;
    for (let k = -w; k <= w; k++) {
      const idx = i + k;
      if (idx >= 0 && idx < raw.length) { sum += raw[idx]; n++; }
    }
    return sum / n;
  });
  const points = smoothed.map((v, i) => [(i / samples) * width, height - v * (height - 6) - 3]);
  const dTop = "M 0," + height + " L " + points.map(p => `${p[0]},${p[1]}`).join(" L ") + ` L ${width},${height} Z`;
  return (
    <g>
      <defs>
        <linearGradient id="energy-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#ff8c42" stopOpacity="0.55" />
          <stop offset="60%" stopColor="#ff4b4b" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#ff4b4b" stopOpacity="0.10" />
        </linearGradient>
      </defs>
      <path d={dTop} fill="url(#energy-grad)" />
      <path d={"M " + points.map(p => `${p[0]},${p[1]}`).join(" L ")}
            fill="none" stroke="#ff8c42" strokeWidth="1.2" opacity="0.9" />
    </g>
  );
}

// ─── The strip itself ──────────────────────────────────────────────
function EventsStrip({
  scope, events, currentMs, selectedId, beginMs, endMs,
  background, beatBpm, onSeek, onSelectEvent, onResizeEvent,
  zoom, onZoomChange, panMs, onPanChange,
  showBeatGrid,
}) {
  const containerRef = stRef(null);
  const [containerW, setContainerW] = stState(1200);
  const [hoverMs, setHoverMs] = stState(null);
  const [drag, setDrag] = stState(null); // { kind: 'begin'|'end', evId }

  stEffect(() => {
    const update = () => {
      if (containerRef.current) setContainerW(containerRef.current.clientWidth);
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const scopeStart = scope.start;
  const scopeEnd = scope.end;
  const scopeRange = scopeEnd - scopeStart;
  // Apply zoom: visible range = scopeRange / zoom, centered on panMs.
  const visibleRange = scopeRange / zoom;
  const visibleStart = Math.max(scopeStart, Math.min(scopeEnd - visibleRange, panMs - visibleRange / 2));
  const visibleEnd = visibleStart + visibleRange;

  const msToPx = ms => ((ms - visibleStart) / visibleRange) * containerW;
  const pxToMs = px => visibleStart + (px / containerW) * visibleRange;

  // Filter events to scope (any overlap with scope window).
  const inScope = events.filter(e => e.end_ms > scopeStart && e.begin_ms < scopeEnd);
  const { events: laneEvents, laneCount } = stMemo(() => packLanes(inScope), [inScope.length, inScope.map(e => e.id + e.begin_ms + e.end_ms).join(",")]);

  const stripHeight = 36 + laneCount * 32 + 8;

  // Beat ticks across the visible range.
  const beatTicks = stMemo(() => {
    const out = [];
    const beatMs = (60 / beatBpm) * 1000;
    const startBeat = Math.floor(visibleStart / beatMs) * beatMs;
    for (let t = startBeat; t <= visibleEnd; t += beatMs) {
      out.push(t);
    }
    return out;
  }, [visibleStart, visibleEnd, beatBpm]);

  // Time ruler labels (every ~120px).
  const ruler = stMemo(() => {
    const out = [];
    const stepMs = (() => {
      const px = 120;
      const targetMs = (px / containerW) * visibleRange;
      const steps = [1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000];
      for (const s of steps) if (s >= targetMs) return s;
      return 60000;
    })();
    const start = Math.floor(visibleStart / stepMs) * stepMs;
    for (let t = start; t <= visibleEnd; t += stepMs) {
      if (t >= visibleStart) out.push(t);
    }
    return out;
  }, [visibleStart, visibleEnd, containerW]);

  const onContainerClick = (e) => {
    if (drag) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    onSeek(pxToMs(x));
  };

  const onContainerMove = (e) => {
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    setHoverMs(pxToMs(x));

    if (drag && onResizeEvent) {
      const ev = events.find(ev => ev.id === drag.evId);
      if (!ev) return;
      const ms = pxToMs(x);
      if (drag.kind === "begin") onResizeEvent(drag.evId, { begin_ms: Math.min(ev.end_ms - 200, ms) });
      if (drag.kind === "end")   onResizeEvent(drag.evId, { end_ms: Math.max(ev.begin_ms + 200, ms) });
    }
  };

  return (
    <div className="ev-strip">
      {/* Toolbar */}
      <div className="ev-strip__toolbar">
        <div className="ev-strip__bgseg">
          {["video", "audio", "spectro", "funscript", "energy", "none"].map(b => (
            <button
              key={b}
              className={"ev-strip__bg" + (background === b ? " ev-strip__bg--on" : "")}
              onClick={() => { if (window.__evSetBackground) window.__evSetBackground(b); }}>
              {b}
            </button>
          ))}
        </div>
        <div className="ev-strip__zoom">
          <button className="ev-strip__zoombtn" onClick={() => onZoomChange(Math.max(1, zoom / 1.5))} title="Zoom out">−</button>
          <span className="ev-strip__zoomread">{zoom.toFixed(1)}×</span>
          <button className="ev-strip__zoombtn" onClick={() => onZoomChange(Math.min(32, zoom * 1.5))} title="Zoom in">+</button>
          <button className="ev-strip__zoombtn ev-strip__zoombtn--reset" onClick={() => { onZoomChange(1); onPanChange((scopeStart + scopeEnd) / 2); }} title="Fit chapter">Fit</button>
        </div>
        <div className="ev-strip__hint">
          click to seek · drag bracket edges to resize · click bracket to select
        </div>
      </div>

      <div
        ref={containerRef}
        className="ev-strip__canvas"
        style={{ height: stripHeight }}
        onClick={onContainerClick}
        onMouseMove={onContainerMove}
        onMouseLeave={() => { setHoverMs(null); if (drag) setDrag(null); }}
        onMouseUp={() => setDrag(null)}
      >
        <svg width="100%" height={stripHeight} style={{ display: "block" }}>
          {/* Background visualization */}
          <g style={{ opacity: 0.7 }}>
            {background === "video"     && <VideoThumbStrip width={containerW} height={stripHeight - 18} scope={scope} />}
            {background === "audio"     && <AudioWaveBg     width={containerW} height={stripHeight - 18} scope={scope} />}
            {background === "spectro"   && <SpectroBg       width={containerW} height={stripHeight - 18} />}
            {background === "funscript" && <FunscriptBg     width={containerW} height={stripHeight - 18} />}
            {background === "energy"    && <EnergyBg        width={containerW} height={stripHeight - 18} />}
          </g>

          {/* Beat grid */}
          {showBeatGrid && beatTicks.map((t, i) => {
            const x = msToPx(t);
            const beatIdx = Math.round((t - visibleStart) / ((60 / beatBpm) * 1000));
            const isDownbeat = beatIdx % 4 === 0;
            return (
              <line key={i} x1={x} x2={x} y1={0} y2={stripHeight - 18}
                stroke={isDownbeat ? "#3a3f5c" : "#2d3148"}
                strokeWidth={isDownbeat ? 1 : 0.5}
                strokeDasharray={isDownbeat ? "" : "2 3"}
                opacity={0.6} />
            );
          })}

          {/* Event brackets */}
          {laneEvents.map(ev => {
            const x1 = msToPx(ev.begin_ms);
            const x2 = msToPx(ev.end_ms);
            const w = Math.max(2, x2 - x1);
            const y = 18 + ev.lane * 32;
            const h = 26;
            const recipe = window.EV_recipeById(ev.recipe);
            const family = window.EV_familyById(recipe?.family);
            const accent = family?.accent || "#9ba3c4";
            const isSelected = ev.id === selectedId;
            const isBaseline = recipe?.isBaseline;

            return (
              <g key={ev.id} style={{ cursor: "pointer" }}
                 onClick={(e) => { e.stopPropagation(); onSelectEvent(ev.id); }}>
                {/* Body */}
                <rect
                  x={x1} y={y} width={w} height={h} rx={3}
                  fill={isBaseline ? "transparent" : accent}
                  fillOpacity={isBaseline ? 0 : (isSelected ? 0.55 : 0.32)}
                  stroke={accent}
                  strokeWidth={isSelected ? 2 : 1}
                  strokeDasharray={isBaseline ? "4 3" : ""}
                />
                {isBaseline && (
                  <pattern id={`hatch-${ev.id}`} width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                    <rect width="3" height="6" fill="#6b7390" opacity="0.18" />
                  </pattern>
                )}
                {isBaseline && (
                  <rect x={x1} y={y} width={w} height={h} rx={3} fill={`url(#hatch-${ev.id})`} pointerEvents="none" />
                )}
                {/* Label */}
                {w > 36 && (
                  <text x={x1 + 6} y={y + 17}
                        fill={isBaseline ? "#9ba3c4" : "#fafafa"}
                        fontSize="11" fontWeight={isSelected ? 600 : 500}
                        style={{ pointerEvents: "none", fontFamily: "var(--font-sans)" }}>
                    {recipe?.label || ev.recipe}
                  </text>
                )}
                {/* Resize handles (visible on hover/select) */}
                {isSelected && (
                  <>
                    <rect x={x1 - 3} y={y} width={6} height={h} fill="#fafafa" opacity="0.0"
                          style={{ cursor: "ew-resize" }}
                          onMouseDown={(e) => { e.stopPropagation(); setDrag({ kind: "begin", evId: ev.id }); }} />
                    <rect x={x2 - 3} y={y} width={6} height={h} fill="#fafafa" opacity="0.0"
                          style={{ cursor: "ew-resize" }}
                          onMouseDown={(e) => { e.stopPropagation(); setDrag({ kind: "end", evId: ev.id }); }} />
                    <line x1={x1} x2={x1} y1={y - 2} y2={y + h + 2} stroke="#fafafa" strokeWidth="2" />
                    <line x1={x2} x2={x2} y1={y - 2} y2={y + h + 2} stroke="#fafafa" strokeWidth="2" />
                  </>
                )}
              </g>
            );
          })}

          {/* Ghost bracket (capture in progress) */}
          {beginMs != null && (
            <g pointerEvents="none">
              <line x1={msToPx(beginMs)} x2={msToPx(beginMs)} y1={0} y2={stripHeight - 18}
                    stroke="#ff8c42" strokeWidth="2" strokeDasharray="3 3" />
              <rect x={msToPx(beginMs) - 1} y={18} width={3} height={26} fill="#ff8c42" />
              <text x={msToPx(beginMs) + 6} y={14} fill="#ff8c42" fontSize="10" fontWeight={600}>BEGIN</text>
              {endMs != null && (
                <>
                  <rect x={msToPx(beginMs)} y={18}
                        width={Math.max(2, msToPx(endMs) - msToPx(beginMs))} height={26} rx={3}
                        fill="#ff8c42" fillOpacity="0.18"
                        stroke="#ff8c42" strokeWidth="1.5" strokeDasharray="4 3" />
                  <line x1={msToPx(endMs)} x2={msToPx(endMs)} y1={0} y2={stripHeight - 18}
                        stroke="#ff8c42" strokeWidth="2" strokeDasharray="3 3" />
                  <text x={msToPx(endMs) - 28} y={14} fill="#ff8c42" fontSize="10" fontWeight={600}>END</text>
                </>
              )}
            </g>
          )}

          {/* Playhead */}
          {currentMs >= visibleStart && currentMs <= visibleEnd && (
            <g pointerEvents="none">
              <line x1={msToPx(currentMs)} x2={msToPx(currentMs)} y1={0} y2={stripHeight}
                    stroke="#ff4b4b" strokeWidth="2" />
              <polygon points={`${msToPx(currentMs)-5},0 ${msToPx(currentMs)+5},0 ${msToPx(currentMs)},7`} fill="#ff4b4b" />
            </g>
          )}

          {/* Hover guide */}
          {hoverMs != null && !drag && (
            <line x1={msToPx(hoverMs)} x2={msToPx(hoverMs)} y1={0} y2={stripHeight - 18}
                  stroke="#fafafa" strokeWidth="1" opacity="0.18" pointerEvents="none" />
          )}

          {/* Time ruler */}
          <g transform={`translate(0,${stripHeight - 16})`}>
            <rect x={0} y={0} width={containerW} height={16} fill="#12151e" />
            {ruler.map((t, i) => (
              <g key={i} transform={`translate(${msToPx(t)},0)`}>
                <line x1={0} x2={0} y1={0} y2={4} stroke="#3a3f5c" strokeWidth="1" />
                <text x={3} y={12} fill="#9ba3c4" fontSize="10"
                      style={{ fontFamily: "var(--font-mono)" }}>
                  {window.EV_fmtTime(t)}
                </text>
              </g>
            ))}
          </g>
        </svg>
      </div>
    </div>
  );
}

Object.assign(window, { EventsStrip });
