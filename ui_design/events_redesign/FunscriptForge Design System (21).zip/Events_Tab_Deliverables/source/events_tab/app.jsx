// Events tab — orchestrator. Wires shell + strip + capture + viewer
// together, holds tab-owned clock and selection state, applies beat-snap +
// chain mode behaviors.

const { useState: appState, useEffect: appEffect, useMemo: appMemo, useRef: appRef } = React;

function EventsTabApp() {
  // Tweaks — surfaced through TweaksPanel below.
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "defaultBackground": "video",
    "chainModeDefault": true,
    "beatSnapDefault": true,
    "showBeatGrid": true,
    "viewerLayout": "right",
    "showHotkeyLegend": false
  }/*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Clock + transport.
  const [currentMs, setCurrentMs] = appState(247000); // start in chapter 3 where events live
  const [isPlaying, setIsPlaying] = appState(false);
  const onPlayPause = () => setIsPlaying(p => !p);

  // Drive playback.
  appEffect(() => {
    if (!isPlaying) return;
    let raf;
    let last = performance.now();
    const tick = (now) => {
      const dt = now - last; last = now;
      setCurrentMs(ms => Math.min(window.EV_PROJECT.duration_ms - 1, ms + dt));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [isPlaying]);

  appEffect(() => { window.__evPlayhead = currentMs; }, [currentMs]);

  // Scope (which chapter).
  const [scopeId, setScopeId] = appState("ch3");
  const scope = window.EV_CHAPTERS.find(c => c.id === scopeId);

  // Strip view state.
  const [background, setBackground] = appState(TWEAK_DEFAULTS.defaultBackground);
  appEffect(() => { setBackground(t.defaultBackground); }, [t.defaultBackground]);
  appEffect(() => { window.__evSetBackground = setBackground; }, []);

  const [zoom, setZoom] = appState(2.0);
  const [panMs, setPanMs] = appState((scope.start + scope.end) / 2);
  appEffect(() => { setPanMs((scope.start + scope.end) / 2); setZoom(2.0); }, [scopeId]);

  // Events working set.
  const [events, setEvents] = appState(window.EV_SAMPLE_EVENTS);

  // Selection.
  const [selectedId, setSelectedId] = appState(null);
  const selectedEvent = events.find(e => e.id === selectedId);

  // Right-side MediaViewer mode.
  const [viewerMode, setViewerMode] = appState("video");

  // Capture state.
  const [beginMs, setBeginMs] = appState(null);
  const [endMs, setEndMs] = appState(null);
  const [recipeId, setRecipeId] = appState("normal");
  const [intensity, setIntensity] = appState(0.6);
  const [params, setParams] = appState({});
  const [devices, setDevices] = appState({});

  // When recipe changes, reset params to that recipe's defaults.
  appEffect(() => {
    const r = window.EV_recipeById(recipeId);
    if (!r || !r.tunables) { setParams({}); return; }
    const d = {};
    r.tunables.forEach(t => { d[t.key] = t.default; });
    setParams(d);
  }, [recipeId]);
  const [chainMode, setChainMode] = appState(TWEAK_DEFAULTS.chainModeDefault);
  const [beatSnap, setBeatSnap] = appState(TWEAK_DEFAULTS.beatSnapDefault);
  appEffect(() => setChainMode(t.chainModeDefault), [t.chainModeDefault]);
  appEffect(() => setBeatSnap(t.beatSnapDefault), [t.beatSnapDefault]);

  // Beat snap helper.
  const snap = (ms) => {
    if (!beatSnap) return ms;
    const beatMs = (60 / window.EV_PROJECT.beat.bpm) * 1000;
    return Math.round(ms / beatMs) * beatMs;
  };

  // Capture actions.
  const onSetBegin = () => {
    const ms = snap(currentMs);
    setBeginMs(ms);
    if (endMs != null && endMs <= ms) setEndMs(null);
  };
  const onSetEnd = () => {
    if (beginMs == null) return;
    const ms = snap(currentMs);
    setEndMs(Math.max(beginMs + 250, ms));
  };
  const onClear = () => { setBeginMs(null); setEndMs(null); };
  const onAdd = () => {
    if (beginMs == null || endMs == null || endMs <= beginMs) return;
    const newEv = {
      id: `e${Date.now().toString(36).slice(-4)}`,
      begin_ms: beginMs, end_ms: endMs,
      recipe: recipeId, intensity,
      params: { ...params },
      devices: { ...devices },
    };
    setEvents(prev => [...prev, newEv]);
    // Chain mode: previous end becomes next begin.
    if (chainMode) {
      setBeginMs(endMs);
      setEndMs(null);
    } else {
      setBeginMs(null); setEndMs(null);
    }
  };

  // Event resize.
  const onResizeEvent = (id, patch) => {
    setEvents(prev => prev.map(e => e.id === id ? { ...e, ...patch } : e));
  };
  const onUpdateSelected = (patch) => {
    if (!selectedEvent) return;
    setEvents(prev => prev.map(e => e.id === selectedEvent.id ? { ...e, ...patch } : e));
  };
  const onDeleteSelected = () => {
    if (!selectedEvent) return;
    setEvents(prev => prev.filter(e => e.id !== selectedEvent.id));
    setSelectedId(null);
  };

  // Seek from strip.
  const onSeek = (ms) => setCurrentMs(Math.max(0, Math.min(window.EV_PROJECT.duration_ms, ms)));
  const onFrameStep = (dir) => setCurrentMs(ms => Math.max(0, ms + dir * 33));

  // What recipe is playing right now? (for overlay on MediaViewer)
  const recipeAtPlayhead = appMemo(() => {
    const active = events.find(e => currentMs >= e.begin_ms && currentMs < e.end_ms);
    if (!active) return null;
    return window.EV_recipeById(active.recipe);
  }, [currentMs, events]);

  // Count events in active scope.
  const scopedEventCount = events.filter(e => e.begin_ms >= scope.start && e.begin_ms < scope.end).length;

  return (
    <div className="ev-app">
      <EvTabStrip />

      <EvChapterRow
        chapters={window.EV_CHAPTERS}
        events={events}
        selectedId={scopeId}
        onSelect={setScopeId}
      />

      {/* Title row */}
      <div className="ev-titlerow">
        <div className="ev-titlerow__left">
          <div className="ev-titlerow__dot" style={{ background: scope.color }} />
          <h2 className="ev-titlerow__name">{scope.label}</h2>
          <span className="ev-titlerow__meta">
            {scopedEventCount} event{scopedEventCount === 1 ? "" : "s"}
            <span className="ev-titlerow__sep">·</span>
            {window.EV_fmtTime(scope.start)} – {window.EV_fmtTime(scope.end)}
            <span className="ev-titlerow__sep">·</span>
            beat {window.EV_PROJECT.beat.bpm} bpm
          </span>
        </div>
        <button className="ev-titlerow__collapse">▾ Collapse</button>
      </div>

      {/* Main body — strip + capture in left column; viewer right column */}
      <div className={"ev-body ev-body--" + t.viewerLayout}>
        <div className="ev-body__center">
          <EventsStrip
            scope={scope}
            events={events}
            currentMs={currentMs}
            selectedId={selectedId}
            beginMs={beginMs}
            endMs={endMs}
            background={background}
            beatBpm={window.EV_PROJECT.beat.bpm}
            zoom={zoom}
            onZoomChange={setZoom}
            panMs={panMs}
            onPanChange={setPanMs}
            showBeatGrid={t.showBeatGrid}
            onSeek={onSeek}
            onSelectEvent={(id) => setSelectedId(id === selectedId ? null : id)}
            onResizeEvent={onResizeEvent}
          />

          <CaptureRow
            beginMs={beginMs}
            endMs={endMs}
            currentMs={currentMs}
            onBeginMsChange={(v) => setBeginMs(Math.max(0, Math.min(window.EV_PROJECT.duration_ms, v)))}
            onEndMsChange={(v) => setEndMs(Math.max((beginMs || 0) + 200, Math.min(window.EV_PROJECT.duration_ms, v)))}
            recipeId={recipeId}
            onRecipeChange={setRecipeId}
            intensity={intensity}
            onIntensityChange={setIntensity}
            params={params}
            onParamsChange={setParams}
            devices={devices}
            onDevicesChange={setDevices}
            chainMode={chainMode}
            onChainModeChange={setChainMode}
            beatSnap={beatSnap}
            onBeatSnapChange={setBeatSnap}
            onSetBegin={onSetBegin}
            onSetEnd={onSetEnd}
            onClear={onClear}
            onAdd={onAdd}
            selectedEvent={selectedEvent}
            onUpdateSelected={onUpdateSelected}
            onDeleteSelected={onDeleteSelected}
            onDeselect={() => setSelectedId(null)}
          />

          {t.showHotkeyLegend && (
            <div className="ev-hotkeys">
              <span className="ev-hotkeys__title">Hotkeys (optional)</span>
              <span className="ev-hotkeys__key"><kbd>I</kbd> set begin</span>
              <span className="ev-hotkeys__key"><kbd>O</kbd> set end</span>
              <span className="ev-hotkeys__key"><kbd>Enter</kbd> add event</span>
              <span className="ev-hotkeys__key"><kbd>Space</kbd> play / pause</span>
              <span className="ev-hotkeys__key"><kbd>,</kbd> <kbd>.</kbd> frame step</span>
              <span className="ev-hotkeys__key"><kbd>1</kbd>–<kbd>9</kbd> pick recipe</span>
            </div>
          )}
        </div>

        <div className="ev-body__right">
          <EvMediaViewer
            currentMs={currentMs}
            isPlaying={isPlaying}
            onPlayPause={onPlayPause}
            onSeek={onSeek}
            onFrameStep={onFrameStep}
            mode={viewerMode}
            onModeChange={setViewerMode}
            recipeAtPlayhead={recipeAtPlayhead}
          />
        </div>
      </div>

      {/* Tweaks panel (toggled via toolbar) */}
      <TweaksPanel title="Events tab — Tweaks">
        <TweakSection title="Editing strip">
          <TweakSelect t={t} setTweak={setTweak} k="defaultBackground" label="Default background"
            options={[
              { value: "video",     label: "Video thumbnails" },
              { value: "audio",     label: "Audio waveform" },
              { value: "spectro",   label: "Spectrogram" },
              { value: "funscript", label: "Funscript band" },
              { value: "energy",    label: "Energy envelope" },
              { value: "none",      label: "None (dark)" },
            ]} />
          <TweakToggle t={t} setTweak={setTweak} k="showBeatGrid" label="Show beat grid" />
        </TweakSection>
        <TweakSection title="Capture flow">
          <TweakToggle t={t} setTweak={setTweak} k="chainModeDefault" label="Chain mode default on"
            help="After Add, the next begin auto-jumps to the just-committed end." />
          <TweakToggle t={t} setTweak={setTweak} k="beatSnapDefault" label="Beat-snap default on" />
          <TweakToggle t={t} setTweak={setTweak} k="showHotkeyLegend" label="Show hotkey legend" />
        </TweakSection>
        <TweakSection title="Layout">
          <TweakRadio t={t} setTweak={setTweak} k="viewerLayout" label="Viewer position"
            options={[
              { value: "right", label: "Right (320px)" },
              { value: "left",  label: "Left (320px)" },
            ]} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<EventsTabApp />);
