# HANDOFF — Events tab integration

**Status:** Design prototype ready for production wiring.
**Audience:** Claude Code (or any engineer) bringing this into FunscriptForge Pro / forgeworkbench.
**Stack target:** Tauri + React 18 + JSX + Vite (per `ARCHITECTURE_ADDENDUM_2026_05.md`).
**Date:** 2026-05-24.

This document covers everything needed to take the design prototype and turn it into a working tab inside the app. The prototype is `Events_Tab.html` + the `events_tab/` folder. The design files are intentionally lightweight — Babel-in-browser, mock data, no real backend wiring — but the **data model, component contracts, and `.feel.yml` schema** they encode are the production design.

---

## 1. File map

```
events_tab/
├── data.js              ← Recipe catalog (EV_RECIPES), families (EV_FAMILIES),
│                          devices (EV_DEVICES), chapters (EV_CHAPTERS),
│                          sample events (EV_SAMPLE_EVENTS), project mock,
│                          helpers (EV_fmtTime, EV_recipeById, EV_familyById)
├── shell.jsx            ← EvTabStrip (top tab bar) + EvChapterRow (scope picker)
├── strip.jsx            ← EventsStrip — the main editing canvas; lane-packing,
│                          background renderers (Video / Audio / Spectro / Funscript
│                          / Energy / None), playhead, beat grid, ghost bracket,
│                          drag-resize handles
├── capture.jsx          ← CaptureRow + SelectedEventEditor + RecipePicker (sectioned,
│                          search, preview waveforms) + RecipeParams + DeviceChevron
│                          + IntensitySlider + RecipePreview
├── viewer.jsx           ← EvMediaViewer (right-side video/audio/spectro/funscript
│                          panel with transport and slow-mo)
├── app.jsx              ← EventsTabApp — orchestrator. Tab-owned clock, scope state,
│                          selection, capture state, beat snap, chain mode,
│                          background, viewer mode, all the wiring.
├── tweaks-panel.jsx     ← Tweaks-panel starter component (not authored here)
├── styles.css           ← Component CSS. Tokens come from colors_and_type.css.
└── feel-yml-sample.txt  ← Canonical .feel.yml excerpt with events section,
                           compose modes, params, and recipe-library projection.
```

The chassis (top tab strip, CHAPTERS scope row, bordered title row, body grid with strip-on-left + viewer-on-right) is the same shape as `tab-Phrases.jsx` in the existing design files — Events inherits the slice-viewer chassis.

---

## 2. Production stack migration

The prototype uses `<script type="text/babel" src="…">` and `window.X` globals. For Vite + React 18:

| Prototype | Production |
|---|---|
| `<script type="text/babel">` blocks | ES modules with named exports |
| `window.EV_RECIPES`, `window.EV_FAMILIES` etc. | Imports from `data.js` or backend via Tauri IPC |
| `window.EV_recipeById(id)` | `import { recipeById } from '../data/recipes'` |
| Inline `data.js` mock | `recipes.json` / `families.json` shipped with the app or loaded from disk |
| Babel CDN React | React 18 npm |
| `window.__evPlayhead`, `window.__evSetBackground` cross-refs | Lift state, drill props, or use context |

Names with the `Ev` / `EV_` prefix are clear-namespace candidates for renaming to plain `Events*` / `events*` in the production code — the prefix was used to avoid colliding with the existing `FF_*` / `FFE_*` namespaces.

---

## 3. Data model — the production schemas

### 3.1 `Event`

```ts
interface Event {
  id: string;                  // stable, lowercase, e.g. "e02"
  begin_ms: number;            // inclusive
  end_ms: number;              // exclusive; must be > begin_ms
  recipe: string;              // FK → Recipe.id
  intensity: number;           // 0..1; ignored when recipe.isBaseline === true
  params?: Record<string, number>;   // overrides for recipe tunables. Absent → recipe defaults.
  devices?: Record<DeviceId, number>; // per-device intensity overrides. Absent → broadcast at `intensity`.
  chapter?: string;            // FK → Chapter.id (denormalized convenience; can be derived)
  snapped_to_beat?: boolean;   // informational; the engine doesn't need this
  notes?: string;              // user freeform
}
```

`devices` semantics:
- Absent or `{}` → broadcast: every device gets the event at `intensity`.
- Any present key sets an absolute override (0..1) for that device.
- Devices NOT mentioned in a non-empty `devices` block: broadcast at the event's `intensity`. *(Subject to review — the alternative is "non-mentioned devices = off"; the prototype assumes broadcast.)*

### 3.2 `Recipe`

```ts
interface Recipe {
  id: string;                  // "surge", "edge", "normal", …
  label: string;               // user-facing
  family: FamilyId;            // FK → Family.id
  desc: string;                // user-facing description, one sentence
  primitives: Primitive[];     // the underlying composition. May be empty for baseline.
  defaults: { intensity: number; duration_ms: number };
  tunables: Tunable[];         // per-recipe parameters with UI metadata
  preview: number[];           // 24 normalized values 0..1 for the preview waveform
  compose?: "additive" | "replace";  // default: "additive". Normal uses "replace".
  isBaseline?: boolean;        // true only for "normal" (rendered with dashed/hatched style)
  tapToCreate?: boolean;       // true → Set End auto-derives from defaults.duration_ms
}

interface Tunable {
  key: string;                 // saved into event.params[key]
  label: string;               // UI label (short)
  min: number; max: number; step: number; default: number;
  unit: string;                // "ms" | "Hz" | "b" | "" — UI suffix only
}

interface Primitive {
  pattern: "pulse" | "wave" | "tremor" | "sustain" | "rolling" | "impact";
  // free-form per-pattern params; see RECIPES.md
  [key: string]: unknown;
}
```

### 3.3 `Family`

```ts
interface Family {
  id: string;                  // "edging", "release", "rhythm", "punctuate", "texture", "baseline"
  label: string;               // user-facing
  accent: string;              // CSS color (drives band/swatch/pill color in the UI)
}
```

### 3.4 `Device`

```ts
interface Device {
  id: "estim" | "vibrator" | "bhaptics" | "shaker";
  label: string;
  icon: string;                // Lucide name (e.g. "zap"); prototype uses string literals
}
```

### 3.5 `Chapter` (inherited from existing FunscriptForge schema)

Already defined in the project. The Events tab consumes it for scope; doesn't author it.

---

## 4. The `.feel.yml` canonical sidecar

`events_tab/feel-yml-sample.txt` is a complete worked example. Highlights for the integration:

1. **Top-level `events:` array** lives alongside the existing `chapters:`, `phrases:`, `beat:` sections. Same file, one canonical sidecar per project.
2. **Recipe library is projected into the file** under `recipe_library:` so the file is self-describing. Downstream tools (ForgePlayer, ForgeStream, restim) read it without needing the workbench installed.
3. **Compose modes** are documented inline as the resolution rules:
   - `additive + additive` → summed per device, capped at 1.0
   - `replace` always wins for its span
   - `replace + replace` → second-authored wins (warn in UI at author time)
4. **Body regions** are an explicit forward-looking field, absent in v1. When haptics ships, `events[*].regions: { chest_l: 1.0, lower_back: 0.6 }` extends the schema without breaking older files.

### Migration from existing JSON sidecars

There is no production data to migrate — there are no users yet and iter-9 was never implemented. The cleanest path:
1. Pick `.feel.yml` (YAML) as canonical going forward. JSON works too if YAML libs are a problem in Rust/Tauri; the schema is the same shape.
2. Existing `<stem>.chapters.json`, `<stem>.phrases.json` etc. continue to exist as *derived* views during the transition. The new authoring writes to `.feel.yml`; the old sidecars are regenerated from it on save.

---

## 5. `.feel.yml` → edger restim playable YAML (the export transform)

This is the load-bearing translation the architecture promises. The `.feel.yml` is **device-agnostic source-of-truth**; restim's event YAML (and bHaptics `.tact`, Freyja JSON, OWO etc.) are **derived per-device export artifacts** generated at export time.

### 5.1 What edger restim consumes (per iter-9 events-data.js)

Each restim event is per-device: it carries `axes` (which device-specific output channels it modulates) and `params` (a flat dict of typed values like `volume`, `pulse_freq`, `pulse_width`, `buzz_freq`, `buzz_intensity`, `volume_boost`, `ramp_in_ms`, `ramp_out_ms`, etc.). Each event has a `mode: additive | replace`. Devices that don't support a given verb are dimmed/omitted.

```yaml
# restim-compatible event YAML excerpt (derived export — NOT authored)
events:
  - id: e02
    begin_ms: 198400
    end_ms:   203100
    device:   estim
    axes:     [pulse_freq, volume, pulse_width]
    params:
      buzz_freq:      12       # Hz
      buzz_intensity: 0.30
      volume_boost:   0.15
      ramp_up_ms:     150
    mode: additive
```

### 5.2 The transform — algorithm

Given one `.feel.yml` event, produce N restim events (one per device the event broadcasts to):

```
for each event in feel.events:
  recipe        = recipe_library[event.recipe]
  effective_int = event.intensity                    // 0..1
  params        = { ...recipe.tunables.defaults, ...event.params }

  // Determine target device set
  if event.devices is absent or empty:
      device_set = all_supported_devices_for(recipe)
  else:
      device_set = keys(event.devices)               // explicit overrides only
                                                     // (see open question in §3.1)

  for each device in device_set:
      device_scaler = (event.devices?.[device]) ?? 1.0
      device_intensity = effective_int * device_scaler

      // Per-device expansion table (lives in the recipe library, alongside primitives)
      restim_event = expand_recipe_for_device(recipe, device, params, device_intensity)
      restim_event.id      = `${event.id}__${device}`
      restim_event.begin_ms = event.begin_ms
      restim_event.end_ms   = event.end_ms
      restim_event.mode     = recipe.compose ?? "additive"
      emit restim_event
```

`expand_recipe_for_device` is the per-device renderer. For `recipe=edge` + `device=estim`:
- recipe.primitives = `[pulse@0.25b, tremor@10Hz×0.30]`
- params (after merge) = `{ tremor_freq: 12, tremor_amount: 0.30, ramp_up_ms: 150 }`
- intensity (after device chevron) = 0.65 × 1.0 = 0.65
- emits:
  ```yaml
  axes: [pulse_freq, volume, pulse_width]
  params:
    buzz_freq:      12      # ← from params.tremor_freq
    buzz_intensity: 0.30    # ← from params.tremor_amount
    volume_boost:   0.15    # ← derived from intensity (heuristic)
    ramp_up_ms:     150     # ← from params.ramp_up_ms
  mode: additive
  ```

For the same `recipe=edge` + `device=vibrator`:
- emits `intensity` curves with `flutter_freq: 12`, `flutter_amplitude: 0.30 * 0.5` (mapping)
- For `device=bhaptics`: emits `vest_chest` zone params, intensity scaled
- For `device=shaker`: emits sub-bass params, intensity scaled

The per-device mapping table is the **device pack** — a function from `(recipe_id, device_id, params, intensity) → device-specific params dict`. Lives in a Python (or Rust) module beside `recipe_library`, version-controlled with the workbench.

### 5.3 What this means for the schema

The `recipe_library` entry needs to declare device support per recipe:

```yaml
recipe_library:
  edge:
    label: Edge
    family: edging
    compose: additive
    primitives: [...]
    tunables: {...}
    device_packs:
      estim:    { axes: [pulse_freq, volume, pulse_width],
                  param_map: { tremor_freq: buzz_freq, tremor_amount: buzz_intensity, ramp_up_ms: ramp_up_ms } }
      vibrator: { axes: [intensity],
                  param_map: { tremor_freq: flutter_freq, tremor_amount: flutter_amplitude } }
      bhaptics: { axes: [vest_chest], zones: [vest] }
      shaker:   { axes: [sub], frequency: 50 }
```

The prototype's `recipe_library` projection in `feel-yml-sample.txt` is intentionally device-pack-free — that lives in the workbench's recipe definition and projects in on save. The Events tab only sees the device-agnostic surface.

### 5.4 Edger-specific compose semantics

Edger events have `mode: additive` already; the Events tab's `compose: additive` maps 1:1. `compose: replace` (Normal) currently has no direct edger equivalent — the cleanest emission is to either:
1. Emit a `mode: replace` event the player honors (preferred — requires a small player change), or
2. Emit a series of `mode: additive` events with negated params that *cancel* whatever recipe is underneath (gross — only do if option 1 is blocked).

Recommend option 1 in coordination with edger.

---

## 6. Component contracts

### `<EventsTabApp />`
Top-level. Owns clock, scope, selection, capture state. In production, lift `currentMs`/`isPlaying` to the AppShell so MediaViewer is shareable across tabs (per addendum §4).

Props (production):
```ts
{
  currentMs: number;
  isPlaying: boolean;
  onPlayPause(): void;
  onSeek(ms: number): void;
  scope: ChapterId | "all";
  onScopeChange(id: ChapterId | "all"): void;
  events: Event[];
  onEventsChange(events: Event[]): void;
  recipes: Recipe[];
  selectedDevices: DeviceId[];  // from Device tab
}
```

### `<EventsStrip />`
Pure presentational + drag handling. Doesn't own data.

Props:
```ts
{
  scope: { start: number; end: number };
  events: Event[];
  currentMs: number;
  selectedId: string | null;
  beginMs: number | null;       // capture state — for ghost bracket
  endMs:   number | null;
  background: "video" | "audio" | "spectro" | "funscript" | "energy" | "none";
  beatBpm: number;
  showBeatGrid: boolean;
  zoom: number;
  panMs: number;
  onZoomChange(z: number): void;
  onPanChange(ms: number): void;
  onSeek(ms: number): void;
  onSelectEvent(id: string): void;
  onResizeEvent(id: string, patch: Partial<Event>): void;
}
```

### `<CaptureRow />` / `<SelectedEventEditor />`
The capture and edit surfaces. See `capture.jsx` for the full prop list.

### `<EvMediaViewer />`
Standard MediaViewer per addendum §4 (the Unified Viewer). In production, replace with the shared component from `forge-reusable-ui`.

---

## 7. Open questions / next steps

1. **Broadcast semantics when `devices` is partial** — see §3.1. Confirm with the team.
2. **Body regions** — when haptics ships, extend `Event` with `regions?: Record<RegionId, number>` and surface a body-silhouette picker in the inspector. Architecture is ready; UI deferred.
3. **Recipe library storage** — file format (single recipes.json? per-recipe YAML?), shipping with the app vs. user-extensible community packs (`~/forge/recipes/<pack>/`).
4. **Hotkeys** — prototype shows a legend but doesn't wire them. Default proposal: `I` set begin, `O` set end, `Enter` add, `Space` play/pause, `,`/`.` frame step, `1–9` arm a recipe.
5. **Compose-replace + edger compatibility** — coordinate with edger to add `mode: replace` support, or emit cancel events as a fallback (§5.4).
6. **Modal palette (#3 in the picker discussion)** — wireframe-ready in `RECIPES.md`. Build when the recipe library passes ~30 entries.
7. **Recipe rename in tab strip** — the prototype renames the "Patterns" tab to "Motifs" to free up the word "patterns" for the modulation alphabet. Production should land this rename in lockstep.

---

## 8. Cross-references

- `events_tab/feel-yml-sample.txt` — canonical sidecar excerpt
- `USER_GUIDE.md` — end-user guide with glossary
- `RECIPES.md` — how to author recipes
- `ARCHITECTURE.md` — design decisions
- `CROSS_DEVICE_PATTERN_THESIS.md` (parent project) — the thesis this design honors
- `ARCHITECTURE_ADDENDUM_2026_05.md` (parent project) — stack + viewer/clock model
