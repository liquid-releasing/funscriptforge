# Events tab — deliverables package

This folder contains everything needed to review, run, and hand off the Events tab redesign.

## Contents

| Path | Purpose |
|---|---|
| **`Events_Tab.standalone.html`** | Self-contained HTML — open in any browser, works offline, no dependencies. The clickable design prototype. |
| **`USER_GUIDE.md`** | End-user guide. How to use the Events tab. Includes the full glossary of terms. |
| **`RECIPES.md`** | Recipe-authoring guide. The recipe shape, every field explained, and a step-by-step walkthrough of building a new recipe. |
| **`ARCHITECTURE.md`** | The design decisions made in this pass, why each call was made, alternatives considered, and what's deferred. |
| **`source/`** | Source files for Claude Code (or any engineer). The HTML + jsx + data.js + styles, with a `HANDOFF.md` covering production-stack migration and the `.feel.yml` → restim YAML transform. |

## Quick start

- **To see the design:** double-click `Events_Tab.standalone.html`. Everything is interactive — try clicking chapters, picking recipes, the Set Begin / Set End flow, clicking events on the strip, opening the Tweaks toolbar toggle.
- **To understand the user model:** read `USER_GUIDE.md`.
- **To understand the data model:** read `ARCHITECTURE.md`, then `source/HANDOFF.md`.
- **To author a new recipe:** read `RECIPES.md`.

## Reading order if you have time for everything

1. `USER_GUIDE.md` — feel what the tab does
2. `ARCHITECTURE.md` — see why it's shaped that way
3. `RECIPES.md` — understand the unit of the recipe library
4. `source/HANDOFF.md` — see what production wiring looks like, including the export pipeline to restim and other devices
5. `source/events_tab/feel-yml-sample.txt` — the canonical sidecar shape

## Project context

Designed against the **Cross-Device Pattern Thesis** in the parent project (`forge-ui-design/CROSS_DEVICE_PATTERN_THESIS.md`). The Events tab is the first surface to fully honor the thesis end-to-end — recipes layered over the primitive modulation alphabet, `.feel.yml` as canonical sidecar, restim YAML / bHaptics / Freyja / OWO as derived device exports, body regions architecturally reserved.

The prototype targets the eventual **forgeworkbench** (renamed FunscriptForge Pro), which also hosts the recipe library this tab consumes.

—
*Liquid Releasing · 2026-05-24*
